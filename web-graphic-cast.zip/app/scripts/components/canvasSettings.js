/**
 * initialize canvas setting panel
 */
(function () {
  "use strict";
  var canvasSettings = function () {
    const _self = this;
    const mainPanel = document.querySelector(
      `${this.containerSelector} .main-panel`
    );
    mainPanel.insertAdjacentHTML(
      "beforeend",
      `<div class="toolpanel" id="background-panel"><div class="content"><p class="title">Canvas Settings</p></div></div>`
    );

    // set dimension section
    (() => {
      const bgPanelContent = document.querySelector(
        `${this.containerSelector} .toolpanel#background-panel .content`
      );
      bgPanelContent.insertAdjacentHTML(
        "beforeend",
        `
        <div class="canvas-size-setting">
          <p>Canvas Size</p>
          <div class="input-container">
            <label>Width</label>
            <div class="custom-number-input">
            <button class="decrease">-</button>
            <input type="number" min="100" id="input-width" value="640"/>
            <button class="increase">+</button>
            </div>
          </div>
          <div class="input-container">
            <label>Height</label>
            <div class="custom-number-input">
            <button class="decrease">-</button>
            <input type="number" min="100" id="input-height" value="480"/>
            <button class="increase">+</button>
            </div>
          </div>
        </div>
        `
      );

      var setDimension = () => {
        try {
          let width = document.querySelector(
            `${this.containerSelector} .toolpanel#background-panel .content #input-width`
          ).value;
          let height = document.querySelector(
            `${this.containerSelector} .toolpanel#background-panel .content #input-height`
          ).value;
          _self.canvas.setWidth(width);
          _self.canvas.originalW = width;
          _self.canvas.setHeight(height);
          _self.canvas.originalH = height;
          _self.canvas.renderAll();
          _self.canvas.trigger("object:modified");
        } catch (_) {}
      };

      document
        .querySelector(
          `${this.containerSelector} .toolpanel#background-panel .content #input-width`
        )
        .addEventListener("change", setDimension);

      document
        .querySelector(
          `${this.containerSelector} .toolpanel#background-panel .content #input-height`
        )
        .addEventListener("change", setDimension);
    })();
    // end set dimension section

    // background color
    (() => {
      const bgPanelContent = document.querySelector(
        `${this.containerSelector} .toolpanel#background-panel .content`
      );
      bgPanelContent.insertAdjacentHTML(
        "beforeend",
        `
        <div class="color-settings">
          <div class="tab-container">
            <div class="tabs">
              <div class="tab-label" data-value="color-fill">Color Fill</div>
              <div class="tab-label" data-value="gradient-fill">Gradient Fill</div>
            </div>
            <div class="tab-content" data-value="color-fill">
              <input id="color-picker" value='black'/><br>
            </div>
            <div class="tab-content" data-value="gradient-fill">
              <div id="gradient-picker"></div>

              <div class="gradient-orientation-container">
                <div class="input-container">
                  <label>Orientation</label>
                  <select id="select-orientation">
                    <option value="linear">Linear</option>
                    <option value="radial">Radial</option>
                  </select>
                </div>
                <div id="angle-input-container" class="input-container">
                  <label>Angle</label>
                  <div class="custom-number-input">
                    <button class="decrease">-</button>
                    <input type="number" min="0" max="360" value="0" id="input-angle">
                    <button class="increase">+</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        `
      );

      document
        .querySelectorAll(
          `${this.containerSelector} .toolpanel#background-panel .content .tab-label`
        )
        .forEach((tab) => {
          tab.addEventListener("click", function () {
            document
              .querySelectorAll(
                `${_self.containerSelector} .toolpanel#background-panel .content .tab-label`
              )
              .forEach((label) => label.classList.remove("active"));

            this.classList.add("active");

            let target = this.getAttribute("data-value");

            this.closest(".tab-container")
              .querySelectorAll(".tab-content")
              .forEach((content) => (content.style.display = "none"));

            let targetContent = this.closest(".tab-container").querySelector(
              `.tab-content[data-value="${target}"]`
            );
            if (targetContent) {
              targetContent.style.display = "block";
            }

            if (target === "color-fill") {
              let colorPicker = document.querySelector(
                `${_self.containerSelector} .toolpanel#background-panel .content #color-picker`
              );
              if (colorPicker) {
                let color = colorPicker.value;
                try {
                  _self.canvas.backgroundColor = color;
                  _self.canvas.renderAll();
                } catch (_) {
                  console.log("Can't update background color");
                }
              }
            } else {
              updateGradientFill();
            }
          });
        });

      const colorFillTab = document.querySelector(
        `${this.containerSelector} .toolpanel#background-panel .content .tab-label[data-value="color-fill"]`
      );
      if (colorFillTab) {
        colorFillTab.click();
      }

      const colorPicker = $(
        `${this.containerSelector} .toolpanel#background-panel .content #color-picker`
      );
      colorPicker.spectrum({
        flat: true,
        showPalette: false,
        showButtons: false,
        type: "color",
        showInput: "true",
        allowEmpty: "false",
        move: function (color) {
          let hex = "transparent";
          color && (hex = color.toRgbString()); // #ff0000
          _self.canvas.backgroundColor = hex;
          _self.canvas.renderAll();
        },
      });

      const gp = new Grapick({
        el: `${this.containerSelector} .toolpanel#background-panel .content #gradient-picker`,
        colorEl: '<input id="colorpicker"/>', // I'll use this for the custom color picker
      });

      gp.setColorPicker((handler) => {
        const el = handler.getEl().querySelector("#colorpicker");
        $(el).spectrum({
          showPalette: false,
          showButtons: false,
          type: "color",
          showInput: "true",
          allowEmpty: "false",
          color: handler.getColor(),
          showAlpha: true,
          change(color) {
            handler.setColor(color.toRgbString());
          },
          move(color) {
            handler.setColor(color.toRgbString(), 0);
          },
        });
      });

      gp.addHandler(0, "red");
      gp.addHandler(100, "blue");

      const updateGradientFill = () => {
        let stops = gp.getHandlers();
        let orientation = document.querySelector(
          `${this.containerSelector} .toolpanel#background-panel .content .gradient-orientation-container #select-orientation`
        ).value;
        let angle = parseInt(
          document.querySelector(
            `${this.containerSelector} .toolpanel#background-panel .content .gradient-orientation-container #input-angle`
          ).value
        );

        let gradient = generateFabricGradientFromColorStops(
          stops,
          _self.canvas.width,
          _self.canvas.height,
          orientation,
          angle
        );
        _self.canvas.setBackgroundColor(gradient);
        _self.canvas.renderAll();
      };

      // Do stuff on change of the gradient
      gp.on("change", (complete) => {
        updateGradientFill();
      });

      const selectOrientations = document.querySelectorAll(
        `${this.containerSelector} .toolpanel#background-panel .content .gradient-orientation-container #select-orientation`
      );

      selectOrientations.forEach((ori) => {
        ori.addEventListener("change", function () {
          let type = this.value;

          let angleInputContainer = this.closest(
            ".gradient-orientation-container"
          ).querySelector("#angle-input-container");

          if (angleInputContainer) {
            angleInputContainer.style.display =
              type === "radial" ? "none" : "block";
          }

          updateGradientFill();
        });
      });

      const inputAngles = document.querySelectorAll(
        `${this.containerSelector} .toolpanel#background-panel .content .gradient-orientation-container #input-angle`
      );
      inputAngles.forEach((input) => {
        input.addEventListener("change", function () {
          updateGradientFill();
        });
      });
    })();
  };

  window.ImageEditor.prototype.initializeCanvasSettingPanel = canvasSettings;
})();
