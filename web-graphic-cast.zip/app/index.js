// CSS 파일들 로드
const loadCSS = function(href) {
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = href;
  document.head.appendChild(link);
};

const cssFiles = [
  "./app/styles/style.css",
  "../vendor/spectrum-colorpicker2/spectrum.min.css",
  "../vendor/grapick/grapick.min.css",
];

cssFiles.forEach(loadCSS);

// jQuery 로드
const loadScript = function (src, callback) {
  const script = document.createElement("script");
  script.src = src;
  script.onload = callback;
  document.head.appendChild(script);
};

loadScript("./vendor/jquery-3.5.1/jquery-3.5.1.min.js", function () {
  jQuery.fn.outerHTML = function () {
    return jQuery("<div />").append(this.eq(0).clone()).html();
  };

  Number.prototype.countDecimals = function () {
    if (Math.floor(this.valueOf()) === this.valueOf()) return 0;
    return this.toString().split(".")[1].length || 0;
  };
});

const scripts = [
  "../vendor/fabric-3.6.3/fabric.min.js",
  "../vendor/spectrum-colorpicker2/spectrum.min.js",
  "../vendor/grapick/grapick.min.js",
  "../vendor/undo-redo-stack/undo-redo-stack.js",
  "./app/scripts/common/core.js",
  "./app/scripts/components/toolbar.js",
  "./app/scripts/components/canvas.js",
  "./app/scripts/components/freeDrawSettings.js",
  "./app/scripts/components/canvasSettings.js",
  "./app/scripts/components/selectionSettings.js",
  "./app/scripts/components/tip.js",
  "./app/scripts/tools/shapes.js",
  "./app/scripts/tools/drawingLine.js",
  "./app/scripts/tools/drawingPath.js",
  "./app/scripts/tools/drawingText.js",
  "./app/scripts/tools/upload.js",
  "./app/scripts/tools/copyPaste.js",
  "./app/scripts/tools/saveInBrowser.js",
  "./app/scripts/utils/utils.js",
  "./app/scripts/utils/zoom.js",
  "./app/scripts/utils/script.js",
];

scripts.forEach((src) => {
  let script = document.createElement("script");
  script.src = src;
  script.async = false;
  document.body.appendChild(script);
});
