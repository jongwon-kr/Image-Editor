/**
 * Define copy/paste actions on Fabric.js canvas
 */
"use strict";

/**
 * Check if a string is a valid JSON object
 * @param {string} s - The string to validate
 * @returns {boolean} - True if it's a valid JSON object, false otherwise
 */
function isJSONObjectString(s) {
  try {
    const o = JSON.parse(s);
    return !!o && typeof o === "object" && !Array.isArray(o);
  } catch {
    return false;
  }
}

/**
 * Check if a string is a valid Base64 encoded string
 * @param {string} str - The string to validate
 * @returns {boolean} - True if it's a valid Base64 string, false otherwise
 */
function isBase64String(str) {
  try {
    str = str.split("base64,").pop();
    window.atob(str);
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Initialize copy and paste functionality on a Fabric.js canvas
 * @param {fabric.Canvas} canvas - The Fabric.js canvas instance
 */
function copyPaste(canvas) {
  // Copy event listener
  document.addEventListener("copy", (e) => {
    if (!canvas.getActiveObject()) return;

    // Copy image as data URL
    if (canvas.getActiveObject().type === "image") {
      e.preventDefault();
      e.clipboardData.setData(
        "text/plain",
        canvas.getActiveObject().toDataURL()
      );
    }

    // Copy non-image objects as JSON
    if (canvas.getActiveObject().type !== "image") {
      e.preventDefault();
      canvas.getActiveObject().clone((cloned) => {
        e.clipboardData.setData("text/plain", JSON.stringify(cloned.toJSON()));
      });
    }
  });

  // Paste event listener
  document.addEventListener("paste", (e) => {
    const pasteTextData = e.clipboardData.getData("text");

    // Paste Base64 image
    if (pasteTextData && isBase64String(pasteTextData)) {
      fabric.Image.fromURL(pasteTextData, (img) => {
        img.set({
          left: 0,
          top: 0,
        });
        img.scaleToHeight(100);
        img.scaleToWidth(100);
        canvas.add(img);
        canvas.setActiveObject(img);
        canvas.trigger("object:modified");
      });
      return;
    }

    // Check clipboard items for image data
    if (e.clipboardData.items.length > 0) {
      for (let i = 0; i < e.clipboardData.items.length; i++) {
        if (e.clipboardData.items[i].type.indexOf("image") === 0) {
          const blob = e.clipboardData.items[i].getAsFile();
          if (blob !== null) {
            const reader = new FileReader();
            reader.onload = (f) => {
              fabric.Image.fromURL(f.target.result, (img) => {
                img.set({
                  left: 0,
                  top: 0,
                });
                img.scaleToHeight(100);
                img.scaleToWidth(100);
                canvas.add(img);
                canvas.setActiveObject(img);
                canvas.trigger("object:modified");
              });
            };
            reader.readAsDataURL(blob);
          }
        }
      }
    }

    // Paste JSON object if valid
    const validTypes = [
      "rect",
      "circle",
      "line",
      "path",
      "polygon",
      "polyline",
      "textbox",
      "group",
    ];
    if (isJSONObjectString(pasteTextData)) {
      const obj = JSON.parse(pasteTextData);
      if (!validTypes.includes(obj.type)) return;

      fabric.util.enlivenObjects([obj], (objects) => {
        objects.forEach((o) => {
          o.set({
            left: 0,
            top: 0,
          });
          canvas.add(o);
          o.setCoords();
          canvas.setActiveObject(o);
        });
        canvas.renderAll();
        canvas.trigger("object:modified");
      });
    }
  });
}

export { copyPaste };
